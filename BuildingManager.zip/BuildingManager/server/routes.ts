import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertBuildingSchema, insertUnitSchema, insertSettingsSchema } from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcrypt";

function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Public API endpoints
  app.get("/api/buildings", async (req, res) => {
    try {
      console.log("Fetching buildings...");
      const buildings = await storage.getBuildings();
      console.log("Buildings fetched:", buildings);
      
      // Get unit counts for each building
      const buildingsWithCounts = await Promise.all(
        buildings.map(async (building) => {
          const units = await storage.getUnits(building.id);
          const availableUnits = units.filter(unit => unit.isAvailable).length;
          const totalUnits = units.length;
          
          return {
            ...building,
            availableUnits,
            totalUnits
          };
        })
      );
      
      res.json(buildingsWithCounts);
    } catch (error) {
      console.error("Error fetching buildings:", error);
      res.status(500).json({ message: "Failed to fetch buildings" });
    }
  });

  app.get("/api/buildings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const building = await storage.getBuilding(id);
      
      if (!building) {
        return res.status(404).json({ message: "Building not found" });
      }
      
      const units = await storage.getUnits(id);
      const amenities = await storage.getBuildingAmenities(id);
      
      res.json({
        ...building,
        units,
        amenities,
        availableUnits: units.filter(unit => unit.isAvailable).length,
        totalUnits: units.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch building details" });
    }
  });

  // Admin API endpoints
  app.get("/api/stats", isAuthenticated, async (req, res) => {
    try {
      const buildingsCount = await storage.getBuildingsCount();
      const availableUnitsCount = await storage.getAvailableUnitsCount();
      const totalUnitsCount = await storage.getTotalUnitsCount();
      
      res.json({
        buildingsCount,
        availableUnitsCount,
        totalUnitsCount
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });
  
  app.get("/api/amenities", async (req, res) => {
    try {
      const amenities = await storage.getAmenities();
      res.json(amenities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch amenities" });
    }
  });

  // CRUD for buildings
  app.post("/api/buildings", isAuthenticated, async (req, res) => {
    try {
      const buildingData = insertBuildingSchema.parse(req.body);
      const building = await storage.createBuilding(buildingData);
      
      // Add amenities if provided
      if (req.body.amenities && Array.isArray(req.body.amenities)) {
        for (const amenityId of req.body.amenities) {
          await storage.addBuildingAmenity({
            buildingId: building.id,
            amenityId: Number(amenityId)
          });
        }
      }
      
      // Add units if provided
      if (req.body.units && Array.isArray(req.body.units)) {
        for (const unitData of req.body.units) {
          const validatedUnit = insertUnitSchema.parse({
            ...unitData,
            buildingId: building.id
          });
          await storage.createUnit(validatedUnit);
        }
      }
      
      res.status(201).json(building);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid building data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create building" });
      }
    }
  });

  app.put("/api/buildings/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const building = await storage.getBuilding(id);
      
      if (!building) {
        return res.status(404).json({ message: "Building not found" });
      }
      
      const buildingData = insertBuildingSchema.partial().parse(req.body);
      const updatedBuilding = await storage.updateBuilding(id, buildingData);
      
      // Update amenities if provided
      if (req.body.amenities && Array.isArray(req.body.amenities)) {
        // Get current amenities
        const currentAmenities = await storage.getBuildingAmenities(id);
        const currentAmenityIds = currentAmenities.map(a => a.id);
        const newAmenityIds = req.body.amenities.map(Number);
        
        // Remove amenities that are no longer in the list
        for (const amenityId of currentAmenityIds) {
          if (!newAmenityIds.includes(amenityId)) {
            await storage.removeBuildingAmenity(id, amenityId);
          }
        }
        
        // Add new amenities
        for (const amenityId of newAmenityIds) {
          if (!currentAmenityIds.includes(amenityId)) {
            await storage.addBuildingAmenity({
              buildingId: id,
              amenityId
            });
          }
        }
      }
      
      res.json(updatedBuilding);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid building data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update building" });
      }
    }
  });

  app.delete("/api/buildings/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const building = await storage.getBuilding(id);
      
      if (!building) {
        return res.status(404).json({ message: "Building not found" });
      }
      
      await storage.deleteBuilding(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete building" });
    }
  });

  // CRUD for units
  app.get("/api/buildings/:buildingId/units", async (req, res) => {
    try {
      const buildingId = parseInt(req.params.buildingId);
      const units = await storage.getUnits(buildingId);
      res.json(units);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch units" });
    }
  });

  app.post("/api/units", isAuthenticated, async (req, res) => {
    try {
      const unitData = insertUnitSchema.parse(req.body);
      const unit = await storage.createUnit(unitData);
      res.status(201).json(unit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid unit data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create unit" });
      }
    }
  });

  app.put("/api/units/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const unit = await storage.getUnit(id);
      
      if (!unit) {
        return res.status(404).json({ message: "Unit not found" });
      }
      
      const unitData = insertUnitSchema.partial().parse(req.body);
      const updatedUnit = await storage.updateUnit(id, unitData);
      res.json(updatedUnit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid unit data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update unit" });
      }
    }
  });

  app.delete("/api/units/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const unit = await storage.getUnit(id);
      
      if (!unit) {
        return res.status(404).json({ message: "Unit not found" });
      }
      
      await storage.deleteUnit(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete unit" });
    }
  });

  // Update user profile
  app.put("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const userData = {
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        whatsapp: req.body.whatsapp
      };
      
      const updatedUser = await storage.updateUser(userId, userData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Change password
  app.put("/api/change-password", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { currentPassword, newPassword } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const isPasswordValid = await comparePasswords(currentPassword, user.password);
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }
      
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(userId, { password: hashedPassword });
      
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to change password" });
    }
  });

  // Settings API endpoints
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.get("/api/settings/:key", async (req, res) => {
    try {
      const key = req.params.key;
      console.log(`Fetching setting with key: ${key}`);
      
      const setting = await storage.getSetting(key);
      
      if (!setting) {
        console.log(`Setting with key '${key}' not found, returning 404`);
        return res.status(404).json({ message: `Setting '${key}' not found` });
      }
      
      console.log(`Successfully retrieved setting: ${JSON.stringify(setting)}`);
      res.json(setting);
    } catch (error) {
      console.error(`Error fetching setting '${req.params.key}':`, error);
      res.status(500).json({ 
        message: "Failed to fetch setting", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.put("/api/settings/:key", isAuthenticated, async (req, res) => {
    try {
      const key = req.params.key;
      const value = req.body.value;
      
      console.log(`Attempting to update setting '${key}' with value:`, typeof value, value?.length || 0);
      
      if (!value && value !== "") {
        console.log(`Invalid value provided for setting '${key}'`);
        return res.status(400).json({ message: "Value is required" });
      }
      
      const updatedSetting = await storage.upsertSetting(key, value);
      console.log(`Successfully updated setting: ${JSON.stringify(updatedSetting)}`);
      res.json(updatedSetting);
    } catch (error) {
      console.error(`Error updating setting '${req.params.key}':`, error);
      res.status(500).json({ 
        message: "Failed to update setting",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.delete("/api/settings/:key", isAuthenticated, async (req, res) => {
    try {
      const key = req.params.key;
      const success = await storage.deleteSetting(key);
      
      if (!success) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete setting" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to compare passwords
async function comparePasswords(supplied: string, stored: string) {
  return bcrypt.compare(supplied, stored);
}
