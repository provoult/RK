import { 
  User, 
  InsertUser, 
  Building, 
  InsertBuilding, 
  Unit, 
  InsertUnit, 
  Amenity, 
  InsertAmenity, 
  BuildingAmenity, 
  InsertBuildingAmenity,
  Settings,
  InsertSettings,
  users,
  buildings,
  units,
  amenities,
  buildingAmenities,
  settings
} from "@shared/schema";
import session from "express-session";
import { db } from "./db";
import { eq, and, count } from "drizzle-orm";
import bcrypt from "bcrypt";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Building operations
  getBuildings(): Promise<Building[]>;
  getBuilding(id: number): Promise<Building | undefined>;
  createBuilding(building: InsertBuilding): Promise<Building>;
  updateBuilding(id: number, building: Partial<Building>): Promise<Building | undefined>;
  deleteBuilding(id: number): Promise<boolean>;

  // Unit operations
  getUnits(buildingId: number): Promise<Unit[]>;
  getUnit(id: number): Promise<Unit | undefined>;
  createUnit(unit: InsertUnit): Promise<Unit>;
  updateUnit(id: number, unit: Partial<Unit>): Promise<Unit | undefined>;
  deleteUnit(id: number): Promise<boolean>;

  // Amenity operations
  getAmenities(): Promise<Amenity[]>;
  getAmenity(id: number): Promise<Amenity | undefined>;
  createAmenity(amenity: InsertAmenity): Promise<Amenity>;
  
  // BuildingAmenity operations
  getBuildingAmenities(buildingId: number): Promise<Amenity[]>;
  addBuildingAmenity(buildingAmenity: InsertBuildingAmenity): Promise<BuildingAmenity>;
  removeBuildingAmenity(buildingId: number, amenityId: number): Promise<boolean>;
  
  // Stats
  getBuildingsCount(): Promise<number>;
  getAvailableUnitsCount(): Promise<number>;
  getTotalUnitsCount(): Promise<number>;
  
  // Settings operations
  getSetting(key: string): Promise<Settings | undefined>;
  getAllSettings(): Promise<Settings[]>;
  upsertSetting(key: string, value: string): Promise<Settings>;
  deleteSetting(key: string): Promise<boolean>;

  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: 'session' 
    });
    
    // Initialize with some data
    this.initData();
  }

  private async initData() {
    // Initialize amenities if they don't exist
    await this.initAmenities();
    
    // Create default admin user if it doesn't exist
    await this.createDefaultUser();
  }

  private async initAmenities() {
    const existingAmenities = await db.select().from(amenities);
    
    if (existingAmenities.length === 0) {
      const amenityNames = [
        "Swimming Pool", "Gym", "Security", "Parking", "CCTV", 
        "Intercom", "Central AC", "Garden", "Elevator", "Maintenance"
      ];
  
      for (const name of amenityNames) {
        await this.createAmenity({ name });
      }
    }
  }

  private async createDefaultUser() {
    const existingUser = await this.getUserByUsername("raashid@alzamilproperties.com");
    
    if (!existingUser) {
      await this.createUser({
        username: "raashid@alzamilproperties.com",
        password: "$2b$10$xHDwN.GJtaNXEzNs1nBmxOAO.jQl4Y1H3CAVu7NZ2DKVY7CeXNVoK", // @RKfit11224
        name: "Raashid",
        email: "raashid@alzamilproperties.com",
        phone: "+973 1729 2977",
        whatsapp: "+973 3968 1234",
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  // Building methods
  async getBuildings(): Promise<Building[]> {
    try {
      console.log("Querying buildings table...");
      const result = await db.select().from(buildings);
      console.log("Buildings query successful, found:", result.length);
      return result;
    } catch (error) {
      console.error("Error in getBuildings:", error);
      throw error;
    }
  }

  async getBuilding(id: number): Promise<Building | undefined> {
    const [building] = await db.select().from(buildings).where(eq(buildings.id, id));
    return building;
  }

  async createBuilding(building: InsertBuilding): Promise<Building> {
    const [newBuilding] = await db.insert(buildings).values(building).returning();
    return newBuilding;
  }

  async updateBuilding(id: number, buildingData: Partial<Building>): Promise<Building | undefined> {
    const [updatedBuilding] = await db
      .update(buildings)
      .set(buildingData)
      .where(eq(buildings.id, id))
      .returning();
    
    return updatedBuilding;
  }

  async deleteBuilding(id: number): Promise<boolean> {
    // Delete associated units
    await db.delete(units).where(eq(units.buildingId, id));
    
    // Delete building amenities
    await db.delete(buildingAmenities).where(eq(buildingAmenities.buildingId, id));
    
    // Delete the building
    const result = await db.delete(buildings).where(eq(buildings.id, id)).returning();
    
    return result.length > 0;
  }

  // Unit methods
  async getUnits(buildingId: number): Promise<Unit[]> {
    return await db.select().from(units).where(eq(units.buildingId, buildingId));
  }

  async getUnit(id: number): Promise<Unit | undefined> {
    const [unit] = await db.select().from(units).where(eq(units.id, id));
    return unit;
  }

  async createUnit(unit: InsertUnit): Promise<Unit> {
    const [newUnit] = await db.insert(units).values(unit).returning();
    return newUnit;
  }

  async updateUnit(id: number, unitData: Partial<Unit>): Promise<Unit | undefined> {
    const [updatedUnit] = await db
      .update(units)
      .set(unitData)
      .where(eq(units.id, id))
      .returning();
    
    return updatedUnit;
  }

  async deleteUnit(id: number): Promise<boolean> {
    const result = await db.delete(units).where(eq(units.id, id)).returning();
    return result.length > 0;
  }

  // Amenity methods
  async getAmenities(): Promise<Amenity[]> {
    return await db.select().from(amenities);
  }

  async getAmenity(id: number): Promise<Amenity | undefined> {
    const [amenity] = await db.select().from(amenities).where(eq(amenities.id, id));
    return amenity;
  }

  async createAmenity(amenity: InsertAmenity): Promise<Amenity> {
    const [newAmenity] = await db.insert(amenities).values(amenity).returning();
    return newAmenity;
  }

  // BuildingAmenity methods
  async getBuildingAmenities(buildingId: number): Promise<Amenity[]> {
    const result = await db
      .select({
        id: amenities.id,
        name: amenities.name
      })
      .from(buildingAmenities)
      .innerJoin(amenities, eq(buildingAmenities.amenityId, amenities.id))
      .where(eq(buildingAmenities.buildingId, buildingId));
    
    return result;
  }

  async addBuildingAmenity(buildingAmenity: InsertBuildingAmenity): Promise<BuildingAmenity> {
    // Check if the relationship already exists
    const [existingRelation] = await db
      .select()
      .from(buildingAmenities)
      .where(
        and(
          eq(buildingAmenities.buildingId, buildingAmenity.buildingId),
          eq(buildingAmenities.amenityId, buildingAmenity.amenityId)
        )
      );
    
    if (existingRelation) {
      return existingRelation;
    }
    
    // Create new relationship
    const [newRelation] = await db
      .insert(buildingAmenities)
      .values(buildingAmenity)
      .returning();
    
    return newRelation;
  }

  async removeBuildingAmenity(buildingId: number, amenityId: number): Promise<boolean> {
    const result = await db
      .delete(buildingAmenities)
      .where(
        and(
          eq(buildingAmenities.buildingId, buildingId),
          eq(buildingAmenities.amenityId, amenityId)
        )
      )
      .returning();
    
    return result.length > 0;
  }

  // Stats methods
  async getBuildingsCount(): Promise<number> {
    const [result] = await db
      .select({ value: count() })
      .from(buildings);
    
    return result?.value || 0;
  }

  async getAvailableUnitsCount(): Promise<number> {
    const [result] = await db
      .select({ value: count() })
      .from(units)
      .where(eq(units.isAvailable, true));
    
    return result?.value || 0;
  }

  async getTotalUnitsCount(): Promise<number> {
    const [result] = await db
      .select({ value: count() })
      .from(units);
    
    return result?.value || 0;
  }
  
  // Settings methods
  async getSetting(key: string): Promise<Settings | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting;
  }
  
  async getAllSettings(): Promise<Settings[]> {
    return await db.select().from(settings);
  }
  
  async upsertSetting(key: string, value: string): Promise<Settings> {
    // Check if setting exists
    const existingSetting = await this.getSetting(key);
    
    if (existingSetting) {
      // Update existing setting
      const [updatedSetting] = await db
        .update(settings)
        .set({ 
          value, 
          updatedAt: new Date() 
        })
        .where(eq(settings.key, key))
        .returning();
      
      return updatedSetting;
    } else {
      // Create new setting
      const [newSetting] = await db
        .insert(settings)
        .values({ 
          key, 
          value 
        })
        .returning();
      
      return newSetting;
    }
  }
  
  async deleteSetting(key: string): Promise<boolean> {
    const result = await db
      .delete(settings)
      .where(eq(settings.key, key))
      .returning();
    
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();