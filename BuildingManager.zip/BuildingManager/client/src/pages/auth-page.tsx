import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/ui/logo";

export default function AuthPage() {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const { user, loginMutation } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    if (user) {
      setLocation("/admin/dashboard");
    }
  }, [user, setLocation]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({
        title: "Error",
        description: "Please enter both username and password",
        variant: "destructive",
      });
      return;
    }
    
    loginMutation.mutate({ username, password });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl">
        <div className="md:grid md:grid-cols-2">
          <div className="bg-primary text-white p-8 rounded-l-lg hidden md:block">
            <div className="h-full flex flex-col justify-between">
              <div>
                <Logo className="h-10 mb-8" />
                <h2 className="text-2xl font-bold mb-4">Property Management System</h2>
                <p className="text-gray-200">
                  Welcome to Al Zamil Properties admin panel. Log in to manage your properties, 
                  buildings, and units from a centralized dashboard.
                </p>
              </div>
              <div className="mt-8">
                <p className="text-sm text-gray-300">
                  &copy; {new Date().getFullYear()} Al Zamil Properties. All rights reserved.
                </p>
              </div>
            </div>
          </div>
          
          <div className="p-8">
            <CardHeader>
              <CardTitle className="text-2xl">Admin Login</CardTitle>
              <CardDescription>Enter your credentials to access the dashboard.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin}>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      id="username" 
                      placeholder="Enter your username"
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input 
                      id="password" 
                      type="password" 
                      placeholder="Enter your password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing In..." : "Sign In"}
                  </Button>
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col items-center border-t pt-4">
              <div className="text-sm text-gray-500 mt-4">
                Default credentials:<br />
                Username: admin<br />
                Password: @RKfit11224
              </div>
            </CardFooter>
          </div>
        </div>
      </Card>
    </div>
  );
}
