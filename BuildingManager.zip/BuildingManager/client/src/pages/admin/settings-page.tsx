import { useState, useEffect, ChangeEvent } from "react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/sidebar";
import { Loader2, Upload } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Logo } from "@/components/ui/logo";

export default function SettingsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [currentLogo, setCurrentLogo] = useState<string | null>(null);

  // Fetch current logo on component mount
  useEffect(() => {
    const fetchCurrentLogo = async () => {
      try {
        const response = await fetch("/api/settings/logo");
        if (response.ok) {
          const data = await response.json();
          if (data && data.value) {
            setCurrentLogo(data.value);
          }
        }
      } catch (error) {
        console.error("Error fetching current logo:", error);
      }
    };

    fetchCurrentLogo();
  }, []);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check if the file is a jpg or png
      if (!file.type.match('image/jpeg|image/jpg|image/png')) {
        toast({
          title: "Invalid file type",
          description: "Please select a JPG or PNG image file",
          variant: "destructive",
        });
        return;
      }
      
      setLogoFile(file);
      
      // Create a preview
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && event.target.result) {
          setLogoPreview(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = async () => {
    if (!logoFile) {
      toast({
        title: "No file selected",
        description: "Please select a logo file to upload",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Resize the image before uploading
      const resizedImage = await resizeImage(logoFile, 300, 100);
      
      // Convert to base64 for storage
      const reader = new FileReader();
      reader.readAsDataURL(resizedImage);
      
      reader.onload = async () => {
        const base64data = reader.result as string;
        
        // Save to settings
        const response = await apiRequest("PUT", "/api/settings/logo", { 
          value: base64data 
        });

        if (response.ok) {
          setCurrentLogo(base64data);
          setLogoPreview(null);
          setLogoFile(null);
          
          toast({
            title: "Logo updated",
            description: "The logo has been updated successfully",
          });
        } else {
          toast({
            title: "Upload failed",
            description: "There was an error uploading the logo",
            variant: "destructive",
          });
        }
        
        setLoading(false);
      };
    } catch (error) {
      console.error("Error uploading logo:", error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading the logo",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  // Helper function to resize the image
  const resizeImage = (file: File, maxWidth: number, maxHeight: number): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get canvas context'));
          return;
        }
        
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Could not create blob'));
            }
          },
          file.type,
          0.8
        );
      };
      
      img.onerror = () => {
        reject(new Error('Error loading image'));
      };
    });
  };

  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="flex">
      <Sidebar />
      
      <div className="flex-1 p-8 bg-gray-50 min-h-screen">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Website Settings</h1>
          
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Website Logo</CardTitle>
              <CardDescription>
                Upload or change the logo that appears on the website. The logo should be in JPG or PNG format.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Current logo display */}
                {currentLogo && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium mb-2">Current Logo</h3>
                    <div className="border rounded p-4 inline-block">
                      <img 
                        src={currentLogo} 
                        alt="Current Logo" 
                        className="h-12 w-auto" 
                      />
                    </div>
                  </div>
                )}
                
                {/* Logo upload */}
                <div>
                  <Label htmlFor="logo" className="block mb-2">Upload New Logo</Label>
                  <Input 
                    id="logo" 
                    type="file" 
                    accept=".jpg,.jpeg,.png" 
                    onChange={handleFileChange}
                    className="mb-4"
                  />
                  
                  {/* Preview */}
                  {logoPreview && (
                    <div className="mb-4">
                      <h3 className="text-sm font-medium mb-2">Preview</h3>
                      <div className="border rounded p-4 inline-block">
                        <img 
                          src={logoPreview} 
                          alt="Logo Preview" 
                          className="h-12 w-auto" 
                        />
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    onClick={handleUpload} 
                    disabled={!logoFile || loading}
                    className="mt-2"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Logo
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}