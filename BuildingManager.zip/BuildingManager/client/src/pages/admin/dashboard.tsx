import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { StatsCard } from "@/components/ui/stats-card";
import { Building, Home, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface BuildingOccupancy {
  name: string;
  percentage: number;
  units: number;
}

interface DashboardStats {
  buildingsCount: number;
  availableUnitsCount: number;
  totalUnitsCount: number;
}

interface RecentActivity {
  id: number;
  text: string;
  date: string;
}

export default function Dashboard() {
  const { data: stats = { buildingsCount: 0, availableUnitsCount: 0, totalUnitsCount: 0 }, isLoading: isLoadingStats } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: buildings = [] } = useQuery<any[]>({
    queryKey: ["/api/buildings"],
  });

  // Calculate building occupancy
  const buildingOccupancy: BuildingOccupancy[] = buildings.map(building => {
    const available = building.availableUnits || 0;
    const total = building.totalUnits || 0;
    const occupied = total - available;
    const percentage = total === 0 ? 0 : Math.round((occupied / total) * 100);
    
    return {
      name: building.name,
      percentage,
      units: total
    };
  });

  // Mock recent activities
  const recentActivities: RecentActivity[] = [
    { id: 1, text: "New tenant added to Juffair Heights", date: "2023-09-15" },
    { id: 2, text: "Maintenance request for Villa 23", date: "2023-09-14" },
    { id: 3, text: "Rent collected from Business Bay", date: "2023-09-12" },
    { id: 4, text: "New property listed in Seef District", date: "2023-09-10" }
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <div className="text-sm font-medium text-gray-500">Admin</div>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <StatsCard 
              title="Total Buildings" 
              value={stats.buildingsCount}
              icon={<Building className="text-secondary text-xl" />}
              color="bg-blue-100"
            />
            
            <StatsCard 
              title="Available Units" 
              value={stats.availableUnitsCount}
              icon={<Home className="text-green-500 text-xl" />}
              color="bg-green-100"
            />
            
            <StatsCard 
              title="Total Units" 
              value={stats.totalUnitsCount}
              icon={<Users className="text-purple-500 text-xl" />}
              color="bg-purple-100"
            />
          </div>
          
          {/* Activity & Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Activities */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {recentActivities.map(activity => (
                    <li key={activity.id} className="flex items-start">
                      <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 mr-3"></div>
                      <div>
                        <p className="text-gray-800">{activity.text}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            {/* Property Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Property Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {buildingOccupancy.map((building, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-700">{building.name}</span>
                        <span className="text-gray-700">{building.percentage}%</span>
                      </div>
                      <Progress value={building.percentage} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">{building.units} units</p>
                    </div>
                  ))}
                  
                  {buildingOccupancy.length === 0 && (
                    <div className="text-center text-gray-500 py-4">
                      No buildings data available
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
