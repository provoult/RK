import { useState, useEffect, useRef } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useFieldArray } from "react-hook-form";
import { z } from "zod";
import { Sidebar } from "@/components/layout/sidebar";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Image, Trash2, Loader2, Eye, Pencil, Upload } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { insertBuildingSchema, Amenity, Building, Unit, BUILDING_CATEGORIES } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";

// Extend schema for form validation
const formSchema = insertBuildingSchema.extend({
  amenities: z.array(z.number()).optional(),
  units: z.array(z.object({
    id: z.number().optional(),
    buildingId: z.number().optional(),
    unitNumber: z.string().min(1, "Unit number is required"),
    bedrooms: z.coerce.number().int().min(0, "Number of bedrooms must be 0 or more"),
    isAvailable: z.boolean().default(true),
  })).optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface PropertyData extends Building {
  units: Unit[];
  amenities: Amenity[];
  availableUnits: number;
  totalUnits: number;
}

export default function EditBuilding() {
  const [, params] = useRoute("/admin/buildings/edit/:id");
  const buildingId = params?.id ? parseInt(params.id) : 0;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch building data
  const { data: building, isLoading: isBuildingLoading } = useQuery<PropertyData>({
    queryKey: [`/api/buildings/${buildingId}`],
    enabled: buildingId > 0,
  });

  // Fetch amenities
  const { data: amenities = [] } = useQuery<Amenity[]>({
    queryKey: ["/api/amenities"],
  });

  // Create form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      buildingNumber: "",
      area: "",
      caretakerName: "",
      caretakerContact: "",
      description: "",
      additionalInfo: "",
      location: "",
      imageUrl: "",
      category: BUILDING_CATEGORIES.AL_ZAMIL_PROPERTIES,
      amenities: [],
      units: [],
    },
  });

  // Setup field array for units
  const { fields: unitFields, append: appendUnit, remove: removeUnit } = useFieldArray({
    control: form.control,
    name: "units",
  });

  // Update form values when building data is loaded
  useEffect(() => {
    if (building) {
      // Get amenity IDs
      const buildingAmenityIds = building.amenities.map(a => a.id);
      
      // Reset form with building data
      form.reset({
        ...building,
        amenities: buildingAmenityIds,
        units: building.units.map(unit => ({
          id: unit.id,
          buildingId: unit.buildingId,
          unitNumber: unit.unitNumber,
          bedrooms: unit.bedrooms,
          isAvailable: unit.isAvailable,
        })),
      });
      
      // Set the preview URL if there's an existing image
      if (building.imageUrl) {
        setPreviewUrl(building.imageUrl);
      }
    }
  }, [building, form]);

  // Mutation for updating building
  const updateBuildingMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("PUT", `/api/buildings/${buildingId}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/buildings"] });
      queryClient.invalidateQueries({ queryKey: [`/api/buildings/${buildingId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Building Updated",
        description: "The building has been successfully updated.",
      });
      setLocation("/admin/buildings");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update building: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: FormValues) => {
    updateBuildingMutation.mutate(data);
  };

  // Handle image upload with resizing
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check file type
    if (!file.type.match(/image\/(jpeg|jpg|png)/)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a JPG or PNG image only.",
        variant: "destructive"
      });
      return;
    }
    
    setImageFile(file);
    
    // Create a preview URL and resize the image
    const reader = new FileReader();
    reader.onloadend = () => {
      // Create an image element to resize
      const img = new window.Image();
      img.onload = function() {
        // Create a canvas to resize the image
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200;
        const MAX_HEIGHT = 800;
        
        let width = img.width;
        let height = img.height;
        
        // Calculate new dimensions while maintaining aspect ratio
        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }
        
        // Set canvas dimensions and draw resized image
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          
          // Convert canvas to data URL with reduced quality
          const resizedDataUrl = canvas.toDataURL(file.type, 0.7); // 70% quality
          
          // Update state with resized image
          setPreviewUrl(resizedDataUrl);
          form.setValue("imageUrl", resizedDataUrl);
          
          toast({
            title: "Image processed",
            description: "Image successfully resized for upload.",
          });
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Trigger file input click
  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  // Add new unit
  const addUnit = () => {
    appendUnit({
      unitNumber: "",
      bedrooms: 2,
      isAvailable: true,
      buildingId: buildingId,
    });
  };

  // Loading state
  if (isBuildingLoading) {
    return (
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-secondary mx-auto mb-4" />
            <p className="text-gray-500">Loading building information...</p>
          </div>
        </div>
      </div>
    );
  }

  // If building not found
  if (!building && !isBuildingLoading) {
    return (
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6 bg-white shadow-md rounded-md">
            <h2 className="text-2xl font-bold text-red-500 mb-2">Building Not Found</h2>
            <p className="text-gray-600 mb-4">The building you are trying to edit does not exist or has been deleted.</p>
            <Link href="/admin/buildings">
              <Button>Go Back to Buildings</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center mb-6">
            <Link href="/admin/buildings">
              <a className="text-gray-500 hover:text-primary mr-2">
                <ArrowLeft size={20} /> Back to Buildings
              </a>
            </Link>
            <h1 className="text-2xl font-bold">Edit Property: {building?.name}</h1>
          </div>
          
          <Card>
            <CardContent className="p-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Property Image */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Property Image</h3>
                    <FormField
                      control={form.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition">
                              {field.value ? (
                                <div className="mb-4">
                                  <img 
                                    src={previewUrl || field.value} 
                                    alt="Building preview" 
                                    className="h-48 mx-auto object-contain rounded-md" 
                                    onError={(e) => {
                                      e.currentTarget.src = "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60";
                                    }}
                                  />
                                </div>
                              ) : (
                                <div className="text-gray-500 mb-4">
                                  <Image className="mx-auto h-16 w-16" />
                                  <p className="mt-2 text-sm">No image uploaded</p>
                                </div>
                              )}
                              
                              <input 
                                type="file" 
                                accept="image/jpeg,image/jpg,image/png" 
                                className="hidden"
                                onChange={handleImageUpload}
                                ref={fileInputRef}
                              />
                              
                              <Button 
                                type="button" 
                                variant="outline" 
                                onClick={triggerFileInput}
                                className="mx-auto flex items-center"
                              >
                                <Upload className="mr-2 h-4 w-4" />
                                Upload Image (PNG/JPG)
                              </Button>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Property Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Property Details</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Building Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="buildingNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Building Number</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="area"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Area</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter area name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="caretakerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Caretaker Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="caretakerContact"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Caretaker Contact</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Property Category</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value || BUILDING_CATEGORIES.AL_ZAMIL_PROPERTIES}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {Object.values(BUILDING_CATEGORIES).map((category) => (
                                  <SelectItem key={category} value={category}>
                                    {category}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {/* Building Location */}
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Building Location (Google Maps Link)</FormLabel>
                        <FormControl>
                          <Input placeholder="Paste Google Maps link here" {...field} />
                        </FormControl>
                        <p className="text-xs text-gray-500 mt-1">
                          Add the Google Maps link to help visitors find the building location
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Property Description */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Property Description</h3>
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Textarea
                              placeholder="Enter property description"
                              className="min-h-[150px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Additional Info */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Additional Info</h3>
                    <FormField
                      control={form.control}
                      name="additionalInfo"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Textarea
                              placeholder="Enter additional information"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Amenities */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Amenities</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                      {amenities.map((amenity) => (
                        <FormField
                          key={amenity.id}
                          control={form.control}
                          name="amenities"
                          render={({ field }) => (
                            <FormItem className="flex items-center space-x-2">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(amenity.id)}
                                  onCheckedChange={(checked) => {
                                    const currentValue = field.value || [];
                                    if (checked) {
                                      field.onChange([...currentValue, amenity.id]);
                                    } else {
                                      field.onChange(
                                        currentValue.filter((value) => value !== amenity.id)
                                      );
                                    }
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                {amenity.name}
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                  </div>
                  
                  {/* Unit Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Unit Details</h3>
                    
                    <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4 shadow-sm">
                      <div className="mb-4 grid grid-cols-12 gap-4 px-4">
                        <div className="col-span-4">
                          <label className="text-sm font-medium uppercase text-gray-700">UNIT NO.</label>
                        </div>
                        <div className="col-span-4">
                          <label className="text-sm font-medium uppercase text-gray-700">BEDROOMS</label>
                        </div>
                        <div className="col-span-4">
                          <label className="text-sm font-medium uppercase text-gray-700">STATUS</label>
                        </div>
                      </div>
                      
                      {unitFields.length > 0 ? (
                        <div className="space-y-4">
                          {unitFields.map((field, index) => (
                            <div key={field.id} className="grid grid-cols-12 gap-4 items-center px-4 py-2">
                              <div className="col-span-4">
                                <FormField
                                  control={form.control}
                                  name={`units.${index}.unitNumber`}
                                  render={({ field }) => (
                                    <FormItem className="mb-0">
                                      <FormControl>
                                        <Input {...field} className="bg-white shadow-sm" />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <div className="col-span-4">
                                <FormField
                                  control={form.control}
                                  name={`units.${index}.bedrooms`}
                                  render={({ field }) => (
                                    <FormItem className="mb-0">
                                      <FormControl>
                                        <Input
                                          type="number"
                                          min="0"
                                          {...field}
                                          className="bg-white shadow-sm"
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <div className="col-span-3">
                                <FormField
                                  control={form.control}
                                  name={`units.${index}.isAvailable`}
                                  render={({ field }) => (
                                    <FormItem className="mb-0">
                                      <FormControl>
                                        <Select
                                          value={field.value ? "available" : "unavailable"}
                                          onValueChange={(value) => field.onChange(value === "available")}
                                        >
                                          <SelectTrigger className="bg-white shadow-sm">
                                            <SelectValue placeholder="Select status" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="available">Available</SelectItem>
                                            <SelectItem value="unavailable">Not Available</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </FormControl>
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <div className="col-span-1 flex justify-end">
                                <Button 
                                  type="button" 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-red-500 hover:text-red-700 p-0 h-8 w-8"
                                  onClick={() => removeUnit(index)}
                                >
                                  <Trash2 size={16} />
                                </Button>
                              </div>
                            </div>
                          ))}
                          
                          <div className="mt-6">
                            <Button
                              type="button"
                              variant="default"
                              size="sm"
                              onClick={addUnit}
                              className="bg-blue-600 hover:bg-blue-700 text-white ml-4"
                            >
                              <Plus size={16} className="mr-1" /> Add Unit
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center space-y-4 py-6">
                          <p className="text-gray-600">No units added yet</p>
                          <Button
                            type="button"
                            variant="default"
                            size="sm"
                            onClick={addUnit}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Plus size={16} className="mr-1" /> Add Unit
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Form Actions */}
                  <div className="flex justify-end space-x-4">
                    <Link href="/admin/buildings">
                      <Button type="button" variant="outline">
                        Cancel
                      </Button>
                    </Link>
                    <Button 
                      type="submit"
                      disabled={updateBuildingMutation.isPending}
                    >
                      {updateBuildingMutation.isPending ? "Updating..." : "Update Property"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
