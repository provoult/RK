import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { BUILDING_CATEGORIES } from "@shared/schema";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Plus, 
  Search, 
  Eye, 
  Edit, 
  Trash2 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface BuildingWithCounts {
  id: number;
  name: string;
  area?: string;
  imageUrl?: string;
  category?: string;
  availableUnits: number;
  totalUnits: number;
}

export default function Buildings() {
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [buildingToDelete, setBuildingToDelete] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [location] = useLocation();
  
  // Extract category from URL if present
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    setSelectedCategory(category);
  }, [location]);
  
  const { toast } = useToast();
  
  const { data: buildings = [], isLoading } = useQuery<BuildingWithCounts[]>({
    queryKey: ["/api/buildings"],
  });
  
  const deleteBuildingMutation = useMutation({
    mutationFn: async (buildingId: number) => {
      await apiRequest("DELETE", `/api/buildings/${buildingId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/buildings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Building deleted",
        description: "The building has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete building: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteClick = (buildingId: number) => {
    setBuildingToDelete(buildingId);
    setDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (buildingToDelete !== null) {
      deleteBuildingMutation.mutate(buildingToDelete);
      setDeleteDialogOpen(false);
      setBuildingToDelete(null);
    }
  };
  
  const filteredBuildings = buildings
    // First filter by category if selected
    .filter(building => {
      if (!selectedCategory) return true;
      
      // Use the category field if available
      if (building.category) {
        return building.category === selectedCategory;
      }
      
      // Fallback to name matching for buildings without category set
      const buildingName = building.name.toLowerCase();
      const categoryLower = selectedCategory.toLowerCase();
      
      return (
        buildingName.includes(categoryLower) ||
        (categoryLower.includes('zamil') && buildingName.includes('zamil'))
      );
    })
    // Then filter by search term
    .filter(building =>
      building.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (building.area && building.area.toLowerCase().includes(searchTerm.toLowerCase()))
    );

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <Link href="/admin/dashboard">
                <a className="text-gray-500 hover:text-primary mr-2">
                  <ArrowLeft size={20} />
                </a>
              </Link>
              <h1 className="text-2xl font-bold">Buildings Management</h1>
            </div>
            <Link href="/admin/buildings/add">
              <Button className="bg-primary text-white hover:bg-secondary">
                <Plus className="mr-2" size={16} /> Add New Building
              </Button>
            </Link>
          </div>
          
          {/* Search and Filter */}
          <div className="mb-6 space-y-4">
            <div className="relative">
              <Input 
                type="text" 
                placeholder="Search buildings..." 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 pl-10" 
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            </div>
            
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={selectedCategory === null ? "default" : "outline"} 
                className="text-sm"
                onClick={() => setSelectedCategory(null)}
              >
                All Categories
              </Button>
              
              {Object.values(BUILDING_CATEGORIES).map(category => (
                <Button 
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"} 
                  className="text-sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Buildings Grid */}
          {isLoading ? (
            <div className="text-center py-10">Loading buildings...</div>
          ) : filteredBuildings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBuildings.map(building => (
                <Card key={building.id} className="overflow-hidden">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={building.imageUrl || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"} 
                      alt={building.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold mb-3">{building.name}</h3>
                    <div className="flex flex-col space-y-2 text-sm mb-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Area:</span>
                        <span>{building.area || "Not specified"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Category:</span>
                        <span>{building.category || "Not specified"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Units</span>
                        <span>{building.totalUnits}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Available</span>
                        <span>{building.availableUnits}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Link href={`/property/${building.id}`}>
                        <Button variant="secondary" className="flex-1">
                          <Eye size={16} className="mr-1" /> View
                        </Button>
                      </Link>
                      <Link href={`/admin/buildings/edit/${building.id}`}>
                        <Button variant="outline" className="flex-1">
                          <Edit size={16} className="mr-1" /> Edit
                        </Button>
                      </Link>
                      <Button 
                        variant="destructive" 
                        size="icon"
                        onClick={() => handleDeleteClick(building.id)}
                        disabled={deleteBuildingMutation.isPending}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-gray-500">
              No buildings found. {searchTerm ? "Try a different search term." : "Add your first building."}
            </div>
          )}
        </div>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the building and all its units. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
