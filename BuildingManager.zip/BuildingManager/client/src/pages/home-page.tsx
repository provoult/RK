import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { PropertyCard } from "@/components/ui/property-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Grid, List } from "lucide-react";
import { Building } from "@shared/schema";

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isGridView, setIsGridView] = useState(true);
  
  const { data: buildings = [], isLoading } = useQuery<(Building & { availableUnits: number, totalUnits: number })[]>({
    queryKey: ["/api/buildings"],
  });
  
  // Filter buildings based on search term and categories
  const filteredBuildings = buildings.filter(building => {
    // Only filter by search term - no category filtering for public view
    const matchesSearch = 
      searchTerm === '' || 
      building.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (building.area && building.area.toLowerCase().includes(searchTerm.toLowerCase()));
    
    return matchesSearch;
  });

  // No need for a separate handleSearch function as filtering happens automatically
  const handleSearch = () => {};

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="hero-section h-96 flex items-center justify-center">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Welcome to Al Zamil Properties</h1>
          <p className="text-xl text-white mb-8">Find your perfect property in our exclusive listings</p>
        </div>
      </section>
      
      {/* Property Listing Section */}
      <section className="py-12 bg-white flex-grow">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">AL ZAMIL PROPERTIES</h2>
          
          {/* Search & Filter Bar */}
          <div className="flex flex-col mb-8 space-y-4">
            {/* Top row with search and view toggle */}
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <div className="flex w-full md:w-auto">
                <div className="relative flex-grow">
                  <Input 
                    type="text" 
                    placeholder="Enter Keyword..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 rounded-r-none"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                </div>
                <Button variant="secondary" onClick={handleSearch} className="rounded-l-none">
                  Search
                </Button>
              </div>
              
              <div className="border rounded-md flex overflow-hidden">
                <Button 
                  variant={isGridView ? "secondary" : "ghost"} 
                  size="sm" 
                  onClick={() => setIsGridView(true)}
                  className="py-2 px-3"
                  title="Grid View"
                >
                  <Grid size={16} />
                </Button>
                <Button 
                  variant={!isGridView ? "secondary" : "ghost"} 
                  size="sm" 
                  onClick={() => setIsGridView(false)}
                  className="py-2 px-3"
                  title="List View"
                >
                  <List size={16} />
                </Button>
              </div>
            </div>
            
            {/* Hidden category filter - will only filter internally */}
          </div>
          
          {/* Property Grid */}
          {isLoading ? (
            <div className="py-10 text-center text-gray-500">Loading properties...</div>
          ) : filteredBuildings.length > 0 ? (
            <div className={isGridView ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
              {filteredBuildings.map(building => (
                <PropertyCard 
                  key={building.id}
                  id={building.id}
                  name={building.name}
                  imageUrl={building.imageUrl || undefined}
                  area={building.area || undefined}
                  availableUnits={building.availableUnits}
                  totalUnits={building.totalUnits}
                  category={building.category ? building.category : undefined}
                />
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-gray-500">
              No properties found. Please try a different search term.
            </div>
          )}
        </div>
      </section>
      
      <Footer />
    </div>
  );
}