import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { PropertyDetail } from "@/components/ui/property-detail";
import { ArrowLeft } from "lucide-react";
import { Building, Unit, Amenity } from "@shared/schema";

interface PropertyData extends Building {
  units: Unit[];
  amenities: Amenity[];
  availableUnits: number;
  totalUnits: number;
}

export default function PropertyPage() {
  const [, params] = useRoute("/property/:id");
  const propertyId = params?.id ? parseInt(params.id) : 0;
  
  const { data: property, isLoading, error } = useQuery<PropertyData>({
    queryKey: [`/api/buildings/${propertyId}`],
    enabled: !!propertyId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <section className="py-12 bg-white flex-grow">
          <div className="container mx-auto px-4">
            <div className="flex justify-center items-center py-20">
              <div className="animate-pulse text-lg">Loading property details...</div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <section className="py-12 bg-white flex-grow">
          <div className="container mx-auto px-4">
            <div className="flex justify-center items-center py-20">
              <div className="text-lg text-red-500">
                Error loading property details. Please try again later.
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <section className="py-8 bg-gradient-to-r from-green-100 to-blue-100 flex-grow">
        <div className="container mx-auto px-4">
          <PropertyDetail 
            id={property.id}
            name={property.name}
            imageUrl={property.imageUrl || undefined}
            buildingNumber={property.buildingNumber || undefined}
            area={property.area || undefined}
            totalUnits={property.totalUnits}
            availableUnits={property.availableUnits}
            caretakerName={property.caretakerName || undefined}
            caretakerContact={property.caretakerContact || undefined}
            description={property.description || undefined}
            additionalInfo={property.additionalInfo || undefined}
            units={property.units}
            amenities={property.amenities}
          />
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
