import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import PropertyPage from "@/pages/property-page";
import AuthPage from "@/pages/auth-page";
import AdminLoginPage from "@/pages/admin-login";
import Dashboard from "@/pages/admin/dashboard";
import Buildings from "@/pages/admin/buildings";
import AddBuilding from "@/pages/admin/add-building";
import EditBuilding from "@/pages/admin/edit-building";
import Profile from "@/pages/admin/profile";
import SettingsPage from "@/pages/admin/settings-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={HomePage} />
      <Route path="/property/:id" component={PropertyPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/admin-login" component={AdminLoginPage} />
      
      {/* Protected Admin Routes */}
      <ProtectedRoute path="/admin" component={Dashboard} />
      <ProtectedRoute path="/admin/dashboard" component={Dashboard} />
      <ProtectedRoute path="/admin/buildings" component={Buildings} />
      <ProtectedRoute path="/admin/buildings/add" component={AddBuilding} />
      <ProtectedRoute path="/admin/buildings/edit/:id" component={EditBuilding} />
      <ProtectedRoute path="/admin/profile" component={Profile} />
      <ProtectedRoute path="/admin/settings" component={SettingsPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthProvider>
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
