import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MapPin,
  User as UserIcon, 
  Phone as PhoneIcon, 
  MessageCircle as WhatsAppIcon,
  Waves,
  Shield,
  Snowflake,
  Dumbbell,
  Car,
  Camera,
  Phone,
  ParkingSquare,
  CableCar,
  FlowerIcon,
  Building,
  Wrench
} from "lucide-react";
import { Amenity } from "@shared/schema";

interface Unit {
  id: number;
  unitNumber: string;
  bedrooms: number;
  isAvailable: boolean;
}

interface PropertyDetailProps {
  id: number;
  name: string;
  imageUrl?: string;
  buildingNumber?: string;
  area?: string;
  totalUnits: number;
  availableUnits: number;
  caretakerName?: string;
  caretakerContact?: string;
  description?: string;
  additionalInfo?: string;
  units: Unit[];
  amenities: Amenity[];
}

export function PropertyDetail({
  name,
  imageUrl,
  buildingNumber,
  area,
  totalUnits,
  availableUnits,
  caretakerName,
  caretakerContact,
  description,
  additionalInfo,
  units,
  amenities
}: PropertyDetailProps) {
  const getAmenityIcon = (amenityName: string) => {
    const name = amenityName.toLowerCase();
    if (name.includes('pool')) return <Waves className="text-green-500" />;
    if (name.includes('gym')) return <Dumbbell className="text-green-500" />;
    if (name.includes('security')) return <Shield className="text-green-500" />;
    if (name.includes('ac') || name.includes('air')) return <Snowflake className="text-green-500" />;
    if (name.includes('parking')) return <Car className="text-green-500" />;
    if (name.includes('cctv')) return <Camera className="text-green-500" />;
    if (name.includes('intercom')) return <Phone className="text-green-500" />;
    if (name.includes('garden')) return <FlowerIcon className="text-green-500" />;
    if (name.includes('elevator')) return <CableCar className="text-green-500" />;
    if (name.includes('maintenance')) return <Wrench className="text-green-500" />;
    return <Building className="text-green-500" />;
  };

  // Background gradient style (mint green to light blue)
  const gradientStyle = {
    background: 'linear-gradient(to right, #a8e6cf, #dcedc1, #ffd3b6, #ffaaa5)'
  };

  return (
    <div className="bg-gradient-to-r from-green-100 to-blue-100 min-h-screen">
      {/* Property Name */}
      <h1 className="text-2xl font-bold py-4">{name}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-6">
        {/* Property Image Column */}
        <div className="md:col-span-5 relative">
          <div className="rounded-lg overflow-hidden shadow-lg">
            <img 
              src={imageUrl || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60"} 
              alt={name} 
              className="w-full h-auto object-cover" 
            />
          </div>
        </div>
        
        {/* Property Details Column */}
        <div className="md:col-span-7">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-6">Property Details</h2>
            
            <div className="grid grid-cols-2 gap-6">
              {/* Area */}
              <div>
                <p className="text-gray-500 text-sm">Area</p>
                <p className="font-semibold">{area || "Juffair"}</p>
              </div>
              
              {/* Building Number */}
              <div>
                <p className="text-gray-500 text-sm">Building Number</p>
                <p className="font-semibold">{buildingNumber || "2317"}</p>
              </div>
              
              {/* Total Units */}
              <div>
                <p className="text-gray-500 text-sm">Total Units</p>
                <p className="font-semibold">{totalUnits || 42}</p>
              </div>
              
              {/* Available Units */}
              <div>
                <p className="text-gray-500 text-sm">Available Units</p>
                <p className="font-semibold">{availableUnits || 8}</p>
              </div>
              
              {/* Caretaker Name */}
              <div>
                <p className="text-gray-500 text-sm">Caretaker Name</p>
                <p className="font-semibold">{caretakerName || "Mohammed Al Sayed"}</p>
              </div>
              
              {/* Caretaker Contact */}
              <div>
                <p className="text-gray-500 text-sm">Caretaker Contact</p>
                <p className="font-semibold">{caretakerContact || "+97339681234"}</p>
              </div>
            </div>
            
            {/* Direction Button */}
            <div className="mt-6">
              <a 
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name} ${area || ''} ${buildingNumber || ''}`)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                  <MapPin className="mr-2 h-4 w-4" /> Get Directions
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Property Description */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Property Description</h2>
        <div className="text-gray-700 whitespace-pre-line">
          {description || "Affordable fully furnished flats 2bhk with balcony and closed kitchen for rent in Adliya, near by AUB, car park spaces. Peaceful area, Great location close to supermarkets and restaurants"}
        </div>
      </div>
      
      {/* Additional Info */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Additional Info</h2>
        {additionalInfo ? (
          <div className="whitespace-pre-line">{additionalInfo}</div>
        ) : (
          <ul className="space-y-2">
            <li>- Rent: 350/- (Fully Furnished)</li>
            <li>- EWA: Inclusive with Limit BD 30/-</li>
            <li>- Municipality tax: Included</li>
            <li>- Internet: Yes</li>
          </ul>
        )}
      </div>
      
      {/* Amenities */}
      {amenities.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 border border-gray-100">
          <h2 className="text-xl font-bold mb-4">Amenities</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-y-6">
            {amenities.map(amenity => (
              <div key={amenity.id} className="flex items-center">
                <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center mr-3 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>{amenity.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Unit Details */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4">Unit Details</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="py-3 px-4 text-left">UNIT NO.</th>
                <th className="py-3 px-4 text-left">BEDROOMS</th>
                <th className="py-3 px-4 text-left">STATUS</th>
              </tr>
            </thead>
            <tbody>
              {units.length > 0 ? units.map(unit => (
                <tr key={unit.id} className="border-b">
                  <td className="py-3 px-4">{unit.unitNumber}</td>
                  <td className="py-3 px-4">{unit.bedrooms}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${unit.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {unit.isAvailable ? "Available" : "Not Available"}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={3} className="py-4 px-4 text-center text-gray-500">
                    No units available for this property
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
