
import { HTMLProps } from "react";
import logoImage from "@assets/Logo for PRF.png";

interface LogoProps extends HTMLProps<HTMLImageElement> {
  className?: string;
}

export function Logo({ className, ...props }: LogoProps) {
  return (
    <img 
      src={logoImage}
      alt="Zamil Properties Logo"
      className={`h-12 w-auto object-contain ${className || ""}`}
      {...props}
    />
  );
}
