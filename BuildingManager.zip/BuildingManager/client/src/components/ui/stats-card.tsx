import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: ReactNode;
  color?: string;
}

export function StatsCard({ title, value, icon, color = "bg-blue-100" }: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6 flex">
        <div className={`rounded-full ${color} p-3 mr-4`}>
          {icon}
        </div>
        <div>
          <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
