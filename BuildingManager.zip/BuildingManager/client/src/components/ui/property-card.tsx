import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface PropertyCardProps {
  id: number;
  name: string;
  imageUrl?: string;
  area?: string;
  availableUnits: number;
  totalUnits: number;
  category?: string;
}

export function PropertyCard({ id, name, imageUrl, area, availableUnits, totalUnits, category }: PropertyCardProps) {
  return (
    <Card className="bg-white rounded-lg overflow-hidden shadow-md border border-gray-200 flex flex-col h-full">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={imageUrl || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"} 
          alt={name} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105" 
        />
      </div>
      <CardContent className="p-4 flex-grow flex flex-col">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <div className="flex justify-between text-sm text-gray-600 mb-4">
          <span>Area: {area || "Not specified"}</span>
          <span>
            Available: <span className={availableUnits > 0 ? "text-green-600 font-medium" : "text-red-600 font-medium"}>
              {availableUnits}
            </span>
          </span>
        </div>
        <Link href={`/property/${id}`} className="mt-auto">
          <Button variant="secondary" className="w-full">
            More Info
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
