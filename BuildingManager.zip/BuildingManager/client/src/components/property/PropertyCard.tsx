import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building } from "@shared/schema";

interface PropertyCardProps {
  property: Building & {
    totalUnits?: number;
    availableUnits?: number;
  };
}

export default function PropertyCard({ property }: PropertyCardProps) {
  // Use property image or a default image
  const imageUrl = property.imageUrl || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60";
  
  return (
    <Card className="overflow-hidden border border-gray-200 flex flex-col h-full">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={property.name} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <CardContent className="p-4 flex-grow">
        <h3 className="text-xl font-semibold mb-2">{property.name}</h3>
        {property.category && (
          <div className="mb-2">
            <Badge variant="outline" className="text-secondary font-normal">
              {property.category}
            </Badge>
          </div>
        )}
        <div className="flex justify-between text-sm text-gray-600 mb-4">
          <span>Area: {property.area || "Not specified"}</span>
          <span>
            Available: {" "}
            <Badge variant="outline" className="text-success font-semibold">
              {property.availableUnits || 0}
            </Badge>
          </span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link 
          href={`/property/${property.id}`}
          className="block text-center bg-secondary text-white py-2 rounded hover:bg-primary transition w-full"
        >
          More Info
        </Link>
      </CardFooter>
    </Card>
  );
}
