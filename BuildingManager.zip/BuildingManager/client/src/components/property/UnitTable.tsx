import { useState } from "react";
import { Unit } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter, 
  DialogTrigger
} from "@/components/ui/dialog";
import { Plus, Trash2, Edit, Check, X } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

interface UnitTableProps {
  units: Unit[];
  onChange: (units: Unit[]) => void;
  buildingId?: number;
}

export default function UnitTable({ units, onChange, buildingId = 0 }: UnitTableProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentUnit, setCurrentUnit] = useState<Unit | null>(null);
  const [newUnit, setNewUnit] = useState<Partial<Unit>>({
    unitNumber: "",
    bedrooms: 0,
    bathrooms: 0,
    isAvailable: true,
    price: "",
    buildingId
  });
  
  // Sort units by unit number
  const sortedUnits = [...units].sort((a, b) => {
    return a.unitNumber.localeCompare(b.unitNumber, undefined, { numeric: true });
  });
  
  // Add a new unit
  const handleAddUnit = () => {
    if (!newUnit.unitNumber) return;
    
    const unitToAdd: Unit = {
      id: undefined, // Will be assigned by the backend
      unitNumber: newUnit.unitNumber,
      bedrooms: newUnit.bedrooms || 0,
      bathrooms: newUnit.bathrooms || 0,
      isAvailable: newUnit.isAvailable !== false,
      price: newUnit.price || "",
      description: newUnit.description || "",
      buildingId,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    onChange([...units, unitToAdd]);
    setNewUnit({
      unitNumber: "",
      bedrooms: 0,
      bathrooms: 0,
      isAvailable: true,
      price: "",
      buildingId
    });
    setIsAddDialogOpen(false);
  };
  
  // Edit an existing unit
  const handleEditUnit = () => {
    if (!currentUnit || !currentUnit.unitNumber) return;
    
    const updatedUnits = units.map(unit => 
      unit.id === currentUnit.id ? currentUnit : unit
    );
    
    onChange(updatedUnits);
    setCurrentUnit(null);
    setIsEditDialogOpen(false);
  };
  
  // Delete a unit
  const handleDeleteUnit = (unitToDelete: Unit) => {
    const updatedUnits = units.filter(unit => unit !== unitToDelete);
    onChange(updatedUnits);
  };
  
  return (
    <div>
      {sortedUnits.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Unit No.</TableHead>
                <TableHead>Bedrooms</TableHead>
                <TableHead>Bathrooms</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-center">Price</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedUnits.map((unit, index) => (
                <TableRow key={unit.id || `new-unit-${index}`}>
                  <TableCell className="font-medium">{unit.unitNumber}</TableCell>
                  <TableCell>{unit.bedrooms}</TableCell>
                  <TableCell>{unit.bathrooms}</TableCell>
                  <TableCell className="text-center">
                    {unit.isAvailable ? (
                      <Badge variant="outline" className="bg-green-100 text-success">
                        Available
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-red-100 text-destructive">
                        Not Available
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-center">{unit.price || "N/A"}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => {
                          setCurrentUnit(unit);
                          setIsEditDialogOpen(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleDeleteUnit(unit)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="border rounded-lg p-4 text-center text-gray-500">
          <p>No units added yet</p>
          <p className="text-sm">Click "Add Unit" to add property units</p>
        </div>
      )}
      
      <div className="mt-4 flex justify-end">
        <Button 
          variant="secondary" 
          onClick={() => setIsAddDialogOpen(true)}
        >
          <Plus className="h-4 w-4 mr-1" /> Add Unit
        </Button>
      </div>
      
      {/* Add Unit Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Unit</DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="unitNumber">Unit Number*</Label>
                <Input 
                  id="unitNumber" 
                  value={newUnit.unitNumber}
                  onChange={(e) => setNewUnit({...newUnit, unitNumber: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="price">Price</Label>
                <Input 
                  id="price" 
                  value={newUnit.price || ""}
                  onChange={(e) => setNewUnit({...newUnit, price: e.target.value})}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="bedrooms">Bedrooms</Label>
                <Input 
                  id="bedrooms" 
                  type="number"
                  value={newUnit.bedrooms || 0}
                  onChange={(e) => setNewUnit({...newUnit, bedrooms: parseInt(e.target.value)})}
                />
              </div>
              <div>
                <Label htmlFor="bathrooms">Bathrooms</Label>
                <Input 
                  id="bathrooms" 
                  type="number"
                  value={newUnit.bathrooms || 0}
                  onChange={(e) => setNewUnit({...newUnit, bathrooms: parseInt(e.target.value)})}
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Switch 
                id="isAvailable" 
                checked={newUnit.isAvailable !== false}
                onCheckedChange={(checked) => setNewUnit({...newUnit, isAvailable: checked})}
              />
              <Label htmlFor="isAvailable">Available</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddUnit}>
              Add Unit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Unit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Unit</DialogTitle>
          </DialogHeader>
          
          {currentUnit && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-unitNumber">Unit Number*</Label>
                  <Input 
                    id="edit-unitNumber" 
                    value={currentUnit.unitNumber}
                    onChange={(e) => setCurrentUnit({...currentUnit, unitNumber: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-price">Price</Label>
                  <Input 
                    id="edit-price" 
                    value={currentUnit.price || ""}
                    onChange={(e) => setCurrentUnit({...currentUnit, price: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-bedrooms">Bedrooms</Label>
                  <Input 
                    id="edit-bedrooms" 
                    type="number"
                    value={currentUnit.bedrooms}
                    onChange={(e) => setCurrentUnit({...currentUnit, bedrooms: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-bathrooms">Bathrooms</Label>
                  <Input 
                    id="edit-bathrooms" 
                    type="number"
                    value={currentUnit.bathrooms}
                    onChange={(e) => setCurrentUnit({...currentUnit, bathrooms: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="edit-isAvailable" 
                  checked={currentUnit.isAvailable}
                  onCheckedChange={(checked) => setCurrentUnit({...currentUnit, isAvailable: checked})}
                />
                <Label htmlFor="edit-isAvailable">Available</Label>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditUnit}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
