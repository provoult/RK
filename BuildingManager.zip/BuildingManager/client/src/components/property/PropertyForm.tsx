import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Building } from "@shared/schema";
import { insertBuildingSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import AmenitiesSelector from "./AmenitiesSelector";
import UnitTable from "./UnitTable";
import { ImageIcon, ChevronLeft } from "lucide-react";
import { Unit, Amenity } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

// Extended building form schema with additional validation
const buildingFormSchema = insertBuildingSchema.extend({
  name: z.string().min(2, "Building name must be at least 2 characters"),
  buildingNumber: z.string().optional(),
  area: z.string().optional(),
  description: z.string().max(1000, "Description cannot exceed 1000 characters").optional(),
  additionalInfo: z.string().max(500, "Additional info cannot exceed 500 characters").optional(),
  caretakerName: z.string().optional(),
  caretakerContact: z.string().optional(),
  location: z.string().optional(),
  imageUrl: z.string().optional(),
});

type BuildingFormValues = z.infer<typeof buildingFormSchema>;

interface PropertyFormProps {
  initialData?: Building;
  existingUnits?: Unit[];
  existingAmenities?: Amenity[];
  isEditing?: boolean;
}

export default function PropertyForm({ 
  initialData, 
  existingUnits = [], 
  existingAmenities = [],
  isEditing = false
}: PropertyFormProps) {
  const [units, setUnits] = useState<Unit[]>(existingUnits);
  const [amenities, setAmenities] = useState<string[]>(
    existingAmenities.map(a => a.name)
  );
  const [imagePreview, setImagePreview] = useState<string | null>(
    initialData?.imageUrl || null
  );
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  
  // Initialize the form with either initial data or default values
  const form = useForm<BuildingFormValues>({
    resolver: zodResolver(buildingFormSchema),
    defaultValues: initialData || {
      name: "",
      buildingNumber: "",
      area: "",
      description: "",
      additionalInfo: "",
      caretakerName: "",
      caretakerContact: "",
      location: "",
      imageUrl: "",
    },
  });
  
  // Mutation for creating or updating a building
  const buildingMutation = useMutation({
    mutationFn: async (values: BuildingFormValues) => {
      if (isEditing && initialData) {
        // Update existing building
        const response = await apiRequest("PATCH", `/api/buildings/${initialData.id}`, values);
        return response.json();
      } else {
        // Create new building
        const response = await apiRequest("POST", "/api/buildings", values);
        return response.json();
      }
    },
    onSuccess: async (building: Building) => {
      // Handle units
      if (isEditing) {
        // For editing: compare units to see what needs to be created/updated/deleted
        const existingUnitIds = existingUnits.map(u => u.id);
        const currentUnitIds = units.map(u => u.id).filter(id => id !== undefined);
        
        // Units to delete (in existingUnits but not in current units)
        const unitsToDelete = existingUnits.filter(
          u => !currentUnitIds.includes(u.id)
        );
        
        // Delete units
        for (const unit of unitsToDelete) {
          await apiRequest("DELETE", `/api/units/${unit.id}`);
        }
        
        // Create or update units
        for (const unit of units) {
          if (!unit.id) {
            // Create new unit
            await apiRequest("POST", "/api/units", {
              ...unit,
              buildingId: building.id
            });
          } else {
            // Update existing unit
            await apiRequest("PATCH", `/api/units/${unit.id}`, unit);
          }
        }
      } else {
        // For new building: create all units
        for (const unit of units) {
          await apiRequest("POST", "/api/units", {
            ...unit,
            buildingId: building.id
          });
        }
      }
      
      // Handle amenities
      if (isEditing) {
        // Delete all existing amenities and create new ones
        for (const amenity of existingAmenities) {
          await apiRequest("DELETE", `/api/amenities/${amenity.id}`);
        }
      }
      
      // Create all amenities
      for (const amenityName of amenities) {
        await apiRequest("POST", "/api/amenities", {
          buildingId: building.id,
          name: amenityName
        });
      }
      
      // Success notification and redirect
      toast({
        title: isEditing ? "Building updated" : "Building created",
        description: `${building.name} has been ${isEditing ? "updated" : "added"} successfully.`
      });
      
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/buildings"] });
      if (isEditing) {
        queryClient.invalidateQueries({ queryKey: [`/api/buildings/${building.id}`] });
      }
      
      // Navigate back to buildings list
      navigate("/admin/buildings");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "create"} building: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Handle form submission
  const onSubmit = (values: BuildingFormValues) => {
    if (imagePreview) {
      values.imageUrl = imagePreview;
    }
    buildingMutation.mutate(values);
  };
  
  // Handle image URL input
  const handleImageUrlChange = (url: string) => {
    setImagePreview(url);
    form.setValue("imageUrl", url);
  };
  
  // Handle file upload from computer
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        setImagePreview(dataUrl);
        form.setValue("imageUrl", dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Navigate back to buildings list
  const goBack = () => {
    navigate("/admin/buildings");
  };
  
  return (
    <div>
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={goBack}
          className="text-gray-500 hover:text-primary mr-2"
        >
          <ChevronLeft className="h-4 w-4 mr-1" /> Back to Buildings
        </Button>
        <h1 className="text-2xl font-bold">
          {isEditing ? `Edit ${initialData?.name}` : "Add New Property"}
        </h1>
      </div>
      
      <Card className="bg-white">
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Property Image */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Property Image</h3>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  {imagePreview ? (
                    <div className="relative">
                      <img 
                        src={imagePreview} 
                        alt="Property Preview" 
                        className="max-h-64 mx-auto rounded" 
                      />
                      <Button 
                        variant="destructive" 
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => setImagePreview(null)}
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="text-gray-500">
                      <div className="mb-4">
                        <ImageIcon className="h-12 w-12 mx-auto text-gray-400" />
                      </div>

                      <div className="flex flex-col space-y-4">
                        {/* File upload option */}
                        <div className="border rounded-md p-4 hover:bg-gray-50 transition">
                          <Label 
                            htmlFor="imageFile" 
                            className="block font-medium mb-2 cursor-pointer"
                          >
                            Upload from your computer
                          </Label>
                          <div className="flex justify-center">
                            <Input 
                              id="imageFile"
                              type="file"
                              accept="image/*"
                              onChange={handleFileUpload}
                              className="max-w-md"
                            />
                          </div>
                        </div>

                        {/* URL option */}
                        <div className="border rounded-md p-4 hover:bg-gray-50 transition">
                          <Label 
                            htmlFor="imageUrl" 
                            className="block font-medium mb-2"
                          >
                            Or enter image URL
                          </Label>
                          <Input 
                            id="imageUrl"
                            placeholder="https://example.com/image.jpg"
                            onChange={(e) => handleImageUrlChange(e.target.value)}
                            className="max-w-md mx-auto"
                          />
                        </div>
                      </div>
                      
                      <p className="text-xs text-gray-400 mt-4">Recommended size: 800x600px</p>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Property Details */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Property Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Building Name*</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="buildingNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Building Number</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="area"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Area</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter area name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="caretakerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Caretaker Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="caretakerContact"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Caretaker Contact</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              {/* Building Location */}
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Building Location (Google Maps Link)</FormLabel>
                    <FormControl>
                      <Input placeholder="Paste Google Maps link here" {...field} />
                    </FormControl>
                    <p className="text-xs text-gray-500 mt-1">
                      Add the Google Maps link to help visitors find the building location
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Property Description */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Property Description</h3>
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Enter details about the property (max 1000 characters)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Textarea 
                            rows={6} 
                            className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-secondary" 
                            maxLength={1000}
                            {...field} 
                          />
                          <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                            {field.value?.length || 0}/1000
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Additional Info */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Additional Info</h3>
                <FormField
                  control={form.control}
                  name="additionalInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional information (max 500 characters)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Textarea 
                            rows={4} 
                            className="w-full p-3 focus:outline-none focus:ring-2 focus:ring-secondary" 
                            maxLength={500}
                            {...field} 
                          />
                          <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                            {field.value?.length || 0}/500
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Amenities */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Amenities</h3>
                <AmenitiesSelector 
                  selectedAmenities={amenities} 
                  onChange={setAmenities} 
                />
              </div>
              
              {/* Unit Details */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-semibold">Unit Details</h3>
                </div>
                <UnitTable 
                  units={units} 
                  onChange={setUnits} 
                  buildingId={initialData?.id} 
                />
              </div>
              
              {/* Form Actions */}
              <Separator />
              <div className="flex justify-end space-x-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={buildingMutation.isPending}
                >
                  {buildingMutation.isPending ? (
                    "Saving..."
                  ) : isEditing ? (
                    "Update Property"
                  ) : (
                    "Add Property"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
