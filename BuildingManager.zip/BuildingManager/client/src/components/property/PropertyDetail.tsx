import { useState } from "react";
import { Building, Unit, Amenity } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { 
  Phone, 
  MessageSquare,
  Waves, 
  Shield, 
  Wind, 
  Dumbbell, 
  Snowflake,
  MapPin,
  Navigation
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PropertyDetailProps {
  building: Building & {
    units: Unit[];
    amenities: Amenity[];
    availableUnits: number;
    totalUnits: number;
  };
}

export default function PropertyDetail({ building }: PropertyDetailProps) {
  const { 
    name, 
    buildingNumber, 
    area, 
    description, 
    additionalInfo, 
    caretakerName, 
    caretakerContact, 
    imageUrl, 
    location,
    units, 
    amenities,
    category
  } = building;
  
  // Use property image or a default image
  const displayImage = imageUrl || "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60";
  
  const getAmenityIcon = (name: string) => {
    const amenityName = name.toLowerCase();
    
    if (amenityName.includes("pool") || amenityName.includes("swimming")) {
      return <Waves className="text-secondary mr-2" />;
    } else if (amenityName.includes("security") || amenityName.includes("cctv")) {
      return <Shield className="text-secondary mr-2" />;
    } else if (amenityName.includes("sauna")) {
      return <Wind className="text-secondary mr-2" />;
    } else if (amenityName.includes("gym")) {
      return <Dumbbell className="text-secondary mr-2" />;
    } else if (amenityName.includes("ac") || amenityName.includes("air")) {
      return <Snowflake className="text-secondary mr-2" />;
    }
    
    return null;
  };
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg">
      <div className="md:flex">
        {/* Property Image */}
        <div className="md:w-1/2">
          <img 
            src={displayImage} 
            alt={name} 
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Property Details */}
        <div className="md:w-1/2 p-6">
          <h2 className="text-2xl font-bold mb-2">{name}</h2>
          {category && (
            <div className="mb-4">
              <Badge variant="outline" className="text-secondary">
                {category}
              </Badge>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-gray-600 text-sm">Building Number</p>
              <p className="font-semibold">{buildingNumber || "N/A"}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Total Units</p>
              <p className="font-semibold">{building.totalUnits}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Available Units</p>
              <p className="font-semibold">{building.availableUnits}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Caretaker Name</p>
              <p className="font-semibold">{caretakerName || "N/A"}</p>
            </div>
          </div>
          
          {caretakerContact && (
            <div className="mb-2">
              <p className="text-gray-600 text-sm">Caretaker Contact</p>
              <div className="flex space-x-2 mt-1">
                <Button size="sm" className="bg-primary text-white flex items-center" asChild>
                  <a href={`tel:${caretakerContact}`}>
                    <Phone className="h-4 w-4 mr-1" /> Call
                  </a>
                </Button>
                <Button size="sm" className="bg-green-500 text-white flex items-center" asChild>
                  <a href={`https://wa.me/${caretakerContact}`}>
                    <MessageSquare className="h-4 w-4 mr-1" /> WhatsApp
                  </a>
                </Button>
              </div>
            </div>
          )}
          
          {location && (
            <div className="mb-6">
              <p className="text-gray-600 text-sm mb-2">Building Location</p>
              <div>
                <Button 
                  size="default" 
                  className="bg-blue-600 hover:bg-blue-700 text-white flex items-center" 
                  asChild
                >
                  <a href={location} target="_blank" rel="noopener noreferrer">
                    <Navigation className="h-5 w-5 mr-2" /> Get Directions via Google Maps
                  </a>
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Property Description */}
      <div className="p-6 border-t">
        <h3 className="text-xl font-semibold mb-4">Property Description</h3>
        <div className="border rounded-lg p-4 mb-6">
          {description ? (
            <div className="text-gray-700 whitespace-pre-line">{description}</div>
          ) : (
            <p className="text-gray-500 italic">No description available.</p>
          )}
        </div>
        
        {/* Additional Info */}
        <h3 className="text-xl font-semibold mb-4">Additional Info</h3>
        <div className="border rounded-lg p-4 mb-6">
          {additionalInfo ? (
            <div className="space-y-2 whitespace-pre-line">{additionalInfo}</div>
          ) : (
            <p className="text-gray-500 italic">No additional information available.</p>
          )}
        </div>
        
        {/* Amenities */}
        <h3 className="text-xl font-semibold mb-4">Amenities</h3>
        {amenities && amenities.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-y-6 mb-6 border border-gray-100 rounded-lg p-6 bg-white">
            {amenities.map((amenity) => (
              <div key={amenity.id} className="flex items-center">
                <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center mr-3 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>{amenity.name}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 italic mb-6">No amenities listed.</p>
        )}
        
        {/* Unit Details */}
        <h3 className="text-xl font-semibold mb-4">Unit Details</h3>
        {units && units.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-3 text-left">UNIT NO.</th>
                  <th className="border p-3 text-left">BEDROOMS</th>
                  <th className="border p-3 text-left">STATUS</th>
                </tr>
              </thead>
              <tbody>
                {units.map((unit) => (
                  <tr key={unit.id}>
                    <td className="border p-3">{unit.unitNumber}</td>
                    <td className="border p-3">{unit.bedrooms}</td>
                    <td className="border p-3">
                      {unit.isAvailable ? (
                        <Badge className="bg-green-100 text-success hover:bg-green-200">
                          Available
                        </Badge>
                      ) : (
                        <Badge variant="destructive" className="bg-red-100 hover:bg-red-200">
                          Not Available
                        </Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500 italic">No units available.</p>
        )}
      </div>
    </div>
  );
}
