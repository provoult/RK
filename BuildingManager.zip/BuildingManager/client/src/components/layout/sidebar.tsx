import { Link, useLocation } from "wouter";
import { Logo } from "../ui/logo";
import { 
  LayoutGrid, 
  Building, 
  UserCog, 
  Globe, 
  LogOut,
  Settings,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { BUILDING_CATEGORIES } from "@shared/schema";

export function Sidebar() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const { toast } = useToast();
  const [buildingsExpanded, setBuildingsExpanded] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isActive = (path: string) => {
    return location.startsWith(path);
  };
  
  const toggleBuildingsMenu = () => {
    setBuildingsExpanded(!buildingsExpanded);
  };

  return (
    <div className="w-64 bg-[#e6f3ff] flex flex-col h-screen shadow-md">
      {/* Logo */}
      <div className="py-6 px-6 border-b border-blue-100 flex justify-center">
        <Logo className="h-12" />
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 py-8 px-4">
        <ul className="space-y-2">
          <li>
            <Link href="/admin/dashboard">
              <a className={`flex items-center px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                isActive('/admin/dashboard') 
                  ? 'bg-blue-200 text-blue-800 font-medium shadow-sm' 
                  : ''
              }`}>
                <LayoutGrid className="w-5 h-5 mr-3 text-blue-600" />
                <span>Dashboard</span>
              </a>
            </Link>
          </li>
          <li className="space-y-1">
            <button 
              onClick={toggleBuildingsMenu}
              className={`flex items-center justify-between w-full px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                isActive('/admin/buildings') 
                  ? 'bg-blue-200 text-blue-800 font-medium shadow-sm' 
                  : ''
              }`}
            >
              <div className="flex items-center">
                <Building className="w-5 h-5 mr-3 text-blue-600" />
                <span>Buildings</span>
              </div>
              {buildingsExpanded ? 
                <ChevronDown className="h-4 w-4" /> : 
                <ChevronRight className="h-4 w-4" />
              }
            </button>
            
            {buildingsExpanded && (
              <ul className="pl-9 space-y-1">
                <li>
                  <Link href="/admin/buildings">
                    <a className={`block py-2 px-3 text-sm text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                      location === "/admin/buildings" 
                        ? 'bg-blue-100 text-blue-700 font-medium' 
                        : ''
                    }`}>
                      All Buildings
                    </a>
                  </Link>
                </li>
                
                {/* Building Categories */}
                {Object.values(BUILDING_CATEGORIES).map((category) => (
                  <li key={category}>
                    <Link href={`/admin/buildings?category=${encodeURIComponent(category)}`}>
                      <a className={`block py-2 px-3 text-sm text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                        location.includes(`/admin/buildings?category=${encodeURIComponent(category)}`) 
                          ? 'bg-blue-100 text-blue-700 font-medium' 
                          : ''
                      }`}>
                        {category}
                      </a>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </li>
          <li>
            <Link href="/admin/profile">
              <a className={`flex items-center px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                isActive('/admin/profile') 
                  ? 'bg-blue-200 text-blue-800 font-medium shadow-sm' 
                  : ''
              }`}>
                <UserCog className="w-5 h-5 mr-3 text-blue-600" />
                <span>Edit Profile</span>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/admin/settings">
              <a className={`flex items-center px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 ${
                isActive('/admin/settings') 
                  ? 'bg-blue-200 text-blue-800 font-medium shadow-sm' 
                  : ''
              }`}>
                <Settings className="w-5 h-5 mr-3 text-blue-600" />
                <span>Settings</span>
              </a>
            </Link>
          </li>
        </ul>
      </nav>
      
      {/* Bottom Links */}
      <div className="py-4 mt-auto border-t border-blue-100 px-4">
        <Link href="/">
          <a className="flex items-center px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-blue-100 mb-2">
            <Globe className="w-5 h-5 mr-3 text-blue-600" />
            <span>Website</span>
          </a>
        </Link>
        <button 
          onClick={handleLogout} 
          className="flex items-center px-4 py-3 text-gray-700 rounded-lg transition-all duration-200 hover:bg-red-100 w-full"
        >
          <LogOut className="w-5 h-5 mr-3 text-red-500" />
          <span className="text-red-600">Logout</span>
        </button>
      </div>
    </div>
  );
}
