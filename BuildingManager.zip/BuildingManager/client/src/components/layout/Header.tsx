import { Link } from "wouter";
import { Phone, Mail, Instagram, Globe, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export default function Header() {
  const { user } = useAuth();

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center">
          <img 
            src="https://i.ibb.co/VH6TWNs/Logo-for-PRF.png" 
            alt="Al Zamil Properties Logo" 
            className="h-12"
          />
        </Link>
        
        {/* Contact Icons */}
        <div className="flex space-x-4">
          <Button variant="ghost" size="icon" asChild aria-label="Call Us">
            <a href="tel:+97317292977" className="text-gray-600 hover:text-primary">
              <Phone className="h-5 w-5" />
            </a>
          </Button>
          
          <Button variant="ghost" size="icon" asChild aria-label="WhatsApp">
            <a href="https://wa.me/+97339681234" className="text-gray-600 hover:text-primary">
              <MessageSquare className="h-5 w-5" />
            </a>
          </Button>
          
          <Button variant="ghost" size="icon" asChild aria-label="Email Us">
            <a href="mailto:raashid@alzamilproperties.com" className="text-gray-600 hover:text-primary">
              <Mail className="h-5 w-5" />
            </a>
          </Button>
          
          <Button variant="ghost" size="icon" asChild aria-label="Instagram">
            <a href="https://www.instagram.com/alzamilproperties" className="text-gray-600 hover:text-primary">
              <Instagram className="h-5 w-5" />
            </a>
          </Button>
          
          <Button variant="ghost" size="icon" asChild aria-label="Website">
            <a href="https://www.alzamilproperties.com" className="text-gray-600 hover:text-primary">
              <Globe className="h-5 w-5" />
            </a>
          </Button>
          
          {user && (
            <Button variant="outline" size="sm" asChild className="ml-2">
              <Link href="/admin/dashboard">Admin Dashboard</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
