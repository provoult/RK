import { Link } from "wouter";
import { Logo } from "../ui/logo";
import { Phone, MessageCircle, Mail, Instagram, Globe, Building } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-100 mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <Logo className="h-16 mb-4" />
            <p className="text-gray-600 mb-4">
              Al Zamil Properties is a leading real estate company in Bahrain, offering premium residential and commercial properties.
            </p>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Phone size={18} className="text-gray-700 mr-2" />
                <a href="tel:+97317292977" className="text-gray-600 hover:text-blue-800">+973 1729 2977</a>
              </li>
              <li className="flex items-center">
                <MessageCircle size={18} className="text-gray-700 mr-2" />
                <a href="https://wa.me/+97339681234" className="text-gray-600 hover:text-blue-800">+973 3968 1234</a>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="text-gray-700 mr-2" />
                <a href="mailto:raashid@alzamilproperties.com" className="text-gray-600 hover:text-blue-800">raashid@alzamilproperties.com</a>
              </li>
              <li className="flex items-center">
                <Instagram size={18} className="text-gray-700 mr-2" />
                <a href="https://www.instagram.com/alzamilproperties" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-blue-800">alzamilproperties</a>
              </li>
              <li className="flex items-center">
                <Globe size={18} className="text-gray-700 mr-2" />
                <a href="https://www.alzamilproperties.com" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-blue-800">www.alzamilproperties.com</a>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-600 hover:text-blue-800">Home</Link>
              </li>
              <li>
                <Link href="/admin-login" className="flex items-center text-gray-600 hover:text-blue-800">
                  <Building size={18} className="mr-2" />
                  Admin Login
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-6 text-center text-gray-600">
          <p>© {currentYear} Al Zamil Properties. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}