import { Link } from "wouter";
import { Phone, Mail } from "lucide-react";

interface FooterProps {
  onLoginClick?: () => void;
}

export default function Footer({ onLoginClick }: FooterProps) {
  return (
    <footer className="bg-primary text-white py-8">
      <div className="container mx-auto px-4">
        <div className="md:flex justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-semibold mb-2">Al Zamil Properties</h3>
            <p className="text-gray-300">Your trusted real estate partner in Bahrain.</p>
          </div>
          
          <div className="mb-4 md:mb-0">
            <h4 className="font-semibold mb-2">Contact Us</h4>
            <div className="space-y-1 text-gray-300">
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>+973 1729 2977</span>
              </div>
              <div className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-2" />
                <span>+973 3968 1234</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span>raashid@alzamilproperties.com</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-2">Quick Links</h4>
            <ul className="space-y-1">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <button
                  onClick={onLoginClick}
                  className="text-gray-300 hover:text-white"
                >
                  Admin Login
                </button>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-gray-700 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Al Zamil Properties. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
