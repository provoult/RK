import { Link, useLocation } from "wouter";
import { Logo } from "../ui/logo";
import { Phone, MessageCircle, Mail, Instagram, Globe, LayoutDashboard } from "lucide-react";
import { Button } from "../ui/button";
import { LoginModal } from "../ui/login-modal";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

export function Header() {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const { user } = useAuth();
  const [location] = useLocation();

  const logoLinkProps = {
    href: "/",
    className: "flex items-center",
    "aria-label": "Al Zamil Properties Home"
  };

  return (
    <>
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <div className="flex items-center">
              <Link {...logoLinkProps}>
                <Logo className="h-20 my-2" />
              </Link>
            </div>
            
            {/* Contact Information and Admin Dashboard Button */}
            <div className="flex items-center space-x-4">
              <a 
                href="tel:+97317292977" 
                className="flex items-center text-gray-700 hover:text-primary transition-colors" 
                aria-label="Call us"
              >
                <Phone size={18} className="text-gray-700" />
              </a>
              <a 
                href="https://wa.me/+97339681234" 
                className="flex items-center text-gray-700 hover:text-primary transition-colors" 
                aria-label="WhatsApp"
              >
                <MessageCircle size={18} className="text-gray-700" />
              </a>
              <a 
                href="mailto:raashid@alzamilproperties.com" 
                className="flex items-center text-gray-700 hover:text-primary transition-colors" 
                aria-label="Email us"
              >
                <Mail size={18} className="text-gray-700" />
              </a>
              <a 
                href="https://www.instagram.com/alzamilproperties" 
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-700 hover:text-primary transition-colors" 
                aria-label="Instagram"
              >
                <Instagram size={18} className="text-gray-700" />
              </a>
              <a 
                href="https://www.alzamilproperties.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-700 hover:text-primary transition-colors" 
                aria-label="Website"
              >
                <Globe size={18} className="text-gray-700" />
              </a>
              
              {/* Admin Dashboard Button */}
              {user && (
                <Link href="/admin">
                  <Button className="ml-4 flex items-center gap-2 bg-blue-900 hover:bg-blue-800">
                    <LayoutDashboard size={18} />
                    <span>Dashboard</span>
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
        {/* Navy blue line below the header */}
        <div className="h-2 bg-blue-900 w-full"></div>
      </header>

      {/* Login Modal */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)}
      />
    </>
  );
}
