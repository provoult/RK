import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Building2, 
  UserCog, 
  Globe, 
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const isActive = (path: string) => {
    return location === path || location.startsWith(`${path}/`);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="w-64 bg-sidebar text-sidebar-foreground flex flex-col h-screen">
      {/* Logo */}
      <div className="py-4 px-6 border-b border-sidebar-border">
        <img 
          src="https://i.ibb.co/VH6TWNs/Logo-for-PRF.png" 
          alt="Al Zamil Properties Logo" 
          className="h-10" 
        />
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 py-4">
        <ul>
          <li className="mb-1">
            <Link 
              href="/admin/dashboard" 
              className={cn(
                "flex items-center py-2 px-6 hover:bg-sidebar-accent rounded transition",
                isActive("/admin/dashboard") && "bg-sidebar-accent"
              )}
            >
              <LayoutDashboard className="w-5 h-5 mr-3" />
              <span>Dashboard</span>
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/admin/buildings" 
              className={cn(
                "flex items-center py-2 px-6 hover:bg-sidebar-accent rounded transition",
                isActive("/admin/buildings") && "bg-sidebar-accent"
              )}
            >
              <Building2 className="w-5 h-5 mr-3" />
              <span>Buildings</span>
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/admin/profile" 
              className={cn(
                "flex items-center py-2 px-6 hover:bg-sidebar-accent rounded transition",
                isActive("/admin/profile") && "bg-sidebar-accent"
              )}
            >
              <UserCog className="w-5 h-5 mr-3" />
              <span>Edit Profile</span>
            </Link>
          </li>
        </ul>
      </nav>
      
      {/* Bottom Links */}
      <div className="py-4 mt-auto border-t border-sidebar-border">
        <Link 
          href="/" 
          className="flex items-center py-2 px-6 hover:bg-sidebar-accent rounded transition"
        >
          <Globe className="w-5 h-5 mr-3" />
          <span>Website</span>
        </Link>
        <button 
          onClick={handleLogout}
          className="w-full flex items-center py-2 px-6 hover:bg-sidebar-accent rounded transition text-left"
        >
          <LogOut className="w-5 h-5 mr-3" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
