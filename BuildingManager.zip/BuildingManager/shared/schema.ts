import { pgTable, text, serial, integer, boolean, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  whatsapp: text("whatsapp"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  phone: true,
  whatsapp: true,
});

// Building Categories
export const BUILDING_CATEGORIES = {
  AHMED_ABDULAZIZ_ALZAMIL: "AHMED ABDULAZIZ ALZAMIL",
  AL_ZAMIL_PROPERTIES: "Al Zamil Properties",
  SAMAZ_REAL_ESTATE: "Samaz Real Estate Company W.L.L",
  ABDULAZIZ_ABDULLA_ALZAMIL: "Abdulaziz Abdulla Al Zamil & Sons Investment Co."
};

// Buildings table
export const buildings = pgTable("buildings", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  buildingNumber: text("building_number"),
  area: text("area"),
  caretakerName: text("caretaker_name"),
  caretakerContact: text("caretaker_contact"),
  description: text("description"),
  additionalInfo: text("additional_info"),
  location: text("location"), // Google Maps link
  imageUrl: text("image_url"),
  category: text("category").default("Al Zamil Properties"),
});

export const insertBuildingSchema = createInsertSchema(buildings).omit({
  id: true,
});

// Units table
export const units = pgTable("units", {
  id: serial("id").primaryKey(),
  buildingId: integer("building_id").notNull(),
  unitNumber: text("unit_number").notNull(),
  bedrooms: integer("bedrooms"),
  isAvailable: boolean("is_available").default(true),
});

export const insertUnitSchema = createInsertSchema(units).omit({
  id: true,
});

// Amenities table
export const amenities = pgTable("amenities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const insertAmenitySchema = createInsertSchema(amenities).omit({
  id: true,
});

// BuildingAmenities join table
export const buildingAmenities = pgTable("building_amenities", {
  id: serial("id").primaryKey(),
  buildingId: integer("building_id").notNull(),
  amenityId: integer("amenity_id").notNull(),
});

export const insertBuildingAmenitySchema = createInsertSchema(buildingAmenities).omit({
  id: true,
});

// Define types based on schemas
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBuilding = z.infer<typeof insertBuildingSchema>;
export type Building = typeof buildings.$inferSelect;

export type InsertUnit = z.infer<typeof insertUnitSchema>;
export type Unit = typeof units.$inferSelect;

export type InsertAmenity = z.infer<typeof insertAmenitySchema>;
export type Amenity = typeof amenities.$inferSelect;

export type InsertBuildingAmenity = z.infer<typeof insertBuildingAmenitySchema>;
export type BuildingAmenity = typeof buildingAmenities.$inferSelect;

// Relations
export const buildingsRelations = relations(buildings, ({ many }) => ({
  units: many(units),
  buildingAmenities: many(buildingAmenities),
}));

export const unitsRelations = relations(units, ({ one }) => ({
  building: one(buildings, {
    fields: [units.buildingId],
    references: [buildings.id],
  }),
}));

export const amenitiesRelations = relations(amenities, ({ many }) => ({
  buildingAmenities: many(buildingAmenities),
}));

export const buildingAmenitiesRelations = relations(buildingAmenities, ({ one }) => ({
  building: one(buildings, {
    fields: [buildingAmenities.buildingId],
    references: [buildings.id],
  }),
  amenity: one(amenities, {
    fields: [buildingAmenities.amenityId],
    references: [amenities.id],
  }),
}));

// Settings table for website configuration (logo, etc.)
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

// Extended schemas for frontend validation
export const loginSchema = z.object({
  username: z.string().email("Please enter a valid email address").min(1, "Email is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginData = z.infer<typeof loginSchema>;
